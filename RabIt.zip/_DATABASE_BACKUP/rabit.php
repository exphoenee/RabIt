<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.0.4
 */

/**
 * Database `rabit`
 */

/* `rabit`.`rabit__advert` */
$rabit__advert = array(
  array('advert_id' => '4','title' => 'Senior Mechanical Engineer','user_id' => '59'),
  array('advert_id' => '6','title' => 'What is Lorem Ipsum?','user_id' => '15'),
  array('advert_id' => '7','title' => 'Dolor Sit Amet!','user_id' => '73'),
  array('advert_id' => '8','title' => 'Senior Mechanical Engineer','user_id' => '62'),
  array('advert_id' => '9','title' => 'Dolor Sit Amet?','user_id' => '15')
);

/* `rabit`.`rabit__user` */
$rabit__user = array(
  array('user_id' => '62','name' => 'exphoenee@gmail.com'),
  array('user_id' => '73','name' => 'Jancsika'),
  array('user_id' => '15','name' => 'Pista'),
  array('user_id' => '60','name' => 'Rozsomák'),
  array('user_id' => '59','name' => 'Viktor Bozzay')
);
