<?php
  require 'system/initialize.php';
  Controller::renderPage();
?>